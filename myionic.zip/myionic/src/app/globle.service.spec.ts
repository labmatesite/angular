import { TestBed, inject } from '@angular/core/testing';

import { GlobleService } from './globle.service';

describe('GlobleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobleService]
    });
  });

  it('should be created', inject([GlobleService], (service: GlobleService) => {
    expect(service).toBeTruthy();
  }));
});
