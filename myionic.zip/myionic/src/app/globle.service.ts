import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import {Observable, of } from 'rxjs';
import {Idata} from './data';
import { map, catchError, tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class GlobleService {

    constructor(private httpc: HttpClient)
    {
    }

    public getPosts(): Observable<Idata[]>
    {
        return this.httpc.get<Idata[]>('http://localhost:4000/history/');
    }
    public getPosts_by_id(id): Observable<Idata[]>
    {
        return this.httpc.get<Idata[]>('http://localhost:4000/history/' + id);
    }
}