import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

 public Homenav =  [

  {
    title: 'History of Gokul',
    url: '/history',
    icon: 'arrow-dropright'
  },
    {
      title: 'Temples',
      url: '/temples',
      icon: 'arrow-dropright'
    },
    {
      title: 'Gallery',
      url: 'gallery',
      icon: 'images'
    },
    {
      title: 'About Gokul',
      url: '/about',
      icon: 'information-circle'
    }
  ];
  constructor() {}
}
