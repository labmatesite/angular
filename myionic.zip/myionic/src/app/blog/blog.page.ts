import { Idata } from './../data';
import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import {ActivatedRoute} from '@angular/router';
import {GlobleService } from '../globle.service';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.page.html',
  styleUrls: ['./blog.page.scss'],
})
export class BlogPage implements OnInit {
  id: string;
  title: string;
  description: string;
  public data: Array<Idata> = [];
  constructor(private route: ActivatedRoute, public service: GlobleService) {
    this.id = route.snapshot.params['id'];
    this.service.getPosts_by_id(this.id).subscribe(value => {
      this.data = value;
      this.title = this.data.title;
      this.description = this.data.description;
   });
}

  ngOnInit() {

  }

}
