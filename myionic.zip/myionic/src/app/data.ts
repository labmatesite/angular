export interface Idata{
  id: string;
  title:string;
  description:string;
  image:string;
}