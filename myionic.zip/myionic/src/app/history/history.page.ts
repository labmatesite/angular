import { Idata } from './../data';
import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import {GlobleService } from '../globle.service';


@Component({
  selector: 'app-history',
  templateUrl: './history.page.html',
  styleUrls: ['./history.page.scss'],
})
export class HistoryPage implements OnInit {

  public data: Array<Idata> = [];
  constructor(public service: GlobleService)
  {
     this.service.getPosts().subscribe(value => {
        this.data= value;
     });
  }

  ngOnInit(){ }
}
